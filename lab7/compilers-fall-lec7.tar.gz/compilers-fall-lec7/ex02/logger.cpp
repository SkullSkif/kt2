#include <iostream>
#include <string>

void loggerLog(const std::string& msg)
{
    std::cout << "log: " << msg << "\n";
}