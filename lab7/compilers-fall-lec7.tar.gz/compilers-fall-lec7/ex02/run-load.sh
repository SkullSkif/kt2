#!/bin/sh

lli -load ./logger.so ./prog.ll

#lli -extra-object ./logger.o ./prog.ll
