#!/bin/sh

lli ./prog.ll
