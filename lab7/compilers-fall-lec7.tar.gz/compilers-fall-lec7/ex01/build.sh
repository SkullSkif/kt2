#!/bin/sh

clang++ -S -emit-llvm ./prog.cpp
