#!/bin/sh


# def f(x) = x*2
# f(20)

# def g(x,y) = x*y+100
# g(8,9)
