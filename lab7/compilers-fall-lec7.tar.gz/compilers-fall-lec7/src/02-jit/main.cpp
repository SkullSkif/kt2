#include <cstdio>

int main(int argc, char** argv)
{
    std::printf("Hello world!\n");
    return 0;
}

