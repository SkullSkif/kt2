#!/bin/sh

./tinylang --filetype=asm --emit-llvm -o module-const-var.ll ./module-const-var.mod
