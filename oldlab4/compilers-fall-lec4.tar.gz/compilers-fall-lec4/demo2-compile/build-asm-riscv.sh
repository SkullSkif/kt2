#!/bin/sh

./tinylang --mtriple=riscv64-unknown-linux-gnu ./Gcd.mod


