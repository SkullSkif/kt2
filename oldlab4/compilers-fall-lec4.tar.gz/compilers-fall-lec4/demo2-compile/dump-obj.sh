#!/bin/sh

objdump --syms ./Gcd.o
objdump -D ./Gcd.o


