#!/bin/sh

./tinylang --filetype=asm --emit-llvm -o Gcd.ll Gcd.mod


