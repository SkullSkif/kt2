#!/bin/sh

./tinylang --filetype=obj ./Gcd.mod



